# ZP Kushtia - Project Context

## Project Overview
Web-based toolset for Zilla Parishad, Kushtia (জেলা পরিষদ, কুষ্টিয়া). Manages beneficiary records: Education Scholarships and Humanitarian Financial Aid.
Live: https://zpkushtia.info

## Tech Stack
- **Runtime:** Node.js 18+ with Express.js
- **Database:** MySQL 9.x (utf8mb4 for Bengali text)
- **Frontend:** HTML5, Vanilla JS, Tailwind CSS (CDN)
- **Server:** Nginx reverse proxy (ServBay) → Node.js on port 3000

## Project Structure
```
config/database.js         — MySQL connection pool
src/server.js              — Express entry point
src/middleware/             — rateLimiter.js, errorHandler.js
src/routes/                — index.js, scholarship.routes.js, humanitarian.routes.js
src/controllers/           — scholarship.controller.js, humanitarian.controller.js
src/models/                — scholarship.model.js, humanitarian.model.js
public/                    — Static HTML (scholarship.html, humanitarian_aid.html)
uploads/                   — File uploads (gitignored)
zpk_mysql_structure.sql    — DB schema
```

## Key Commands
- `npm run dev` — Development with auto-restart
- `npm start` — Production

## Database
- DB name: `zpk`
- Tables: `scholarship`, `humanitarian_aid`
- Bengali language content — always use utf8mb4
- Full-text search indexes on name fields

## API Pattern
All APIs under `/api/`. Each module (scholarship, humanitarian) has:
- `GET /api/{module}/search?q={query}&year={year}` — Search (top 10)
- `GET /api/{module}/:id` — Get by ID
- `GET /api/{module}/years` — List financial years
- `GET /api/{module}/stats` — Statistics
- `GET /api/{module}/list?page=1&limit=20` — Paginated list

## Code Conventions
- Express MVC pattern: routes → controllers → models
- Models use raw MySQL queries (no ORM)
- Frontend uses vanilla JS with fetch API
- Bengali UI text throughout — preserve Bengali strings as-is
- Rate limiting on all API endpoints

## Important Notes
- `.env` contains DB credentials — never commit
- `ssl/` directory is gitignored
- `uploads/` directory is gitignored
- No test framework set up yet
- Roadmap: JWT auth, admin dashboard, project management tool, landing page
