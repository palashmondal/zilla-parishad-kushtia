-- ============================================================
-- Seed 001: Dummy Projects — Development / Testing Data
-- ZP Kushtia (জেলা পরিষদ, কুষ্টিয়া)
-- Run AFTER: database/migrations/003_create_projects.sql
-- ============================================================
-- NOTE: `project_approval_date` column is excluded here.
-- If you have added that column, run the UPDATE block at the
-- bottom of this file to populate it.
-- ============================================================
-- Coverage:
--   টেন্ডার  : 4 rows — all 4 Tender statuses
--   সিপিপিসি : 4 rows — 4 of 6 CPPC statuses
--   আরএফকিউ : 2 rows — early and completed RFQ
--   project_type : শিক্ষা×3, সেবামূলক×3, ধর্মীয় ও সামাজিক×2, ক্রীড়া×2
--   Delayed  : project_id R-25-26-003, R-25-26-007
--   Completed: project_id R-25-26-004, R-25-26-008, R-25-26-010
-- ============================================================

INSERT INTO `projects` (
    `project_name`,
    `project_id`,
    `allocation_amount`,
    `released_amount`,
    `fund_type`,
    `financial_year`,
    `implementation_method`,
    `upazila`,
    `project_type`,
    `current_status`,
    `progress_percentage`,
    `is_completed`,
    `is_delayed`,
    `performance_score`,
    `start_date`,
    `expected_end_date`,
    `actual_end_date`,
    `remarks`,
    `created_by`
) VALUES

-- ============================================================
-- টেন্ডার projects (001–004)
-- ============================================================

-- 001: Tender | সেবামূলক | টেন্ডার ফ্লোটিং | Early stage, no score
(
    'কুষ্টিয়া সদর উপজেলাধীন পৌর এলাকায় প্রধান সড়কের ড্রেন ও পেভমেন্ট সংস্কার কাজ',
    'R-25-26-001',
    1500000.00,
    0.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (সাধারণ বরাদ্দ)',
    '২০২৫-২৬',
    'টেন্ডার',
    'কুষ্টিয়া সদর',
    'সেবামূলক',
    'টেন্ডার ফ্লোটিং',
    5,
    0,
    0,
    NULL,
    '2025-07-01',
    '2025-12-31',
    NULL,
    'টেন্ডার নথিপত্র প্রস্তুত সম্পন্ন; ই-জিপি পোর্টালে বিজ্ঞপ্তি প্রকাশিত',
    NULL
),

-- 002: Tender | শিক্ষা | কার্যাদেশ সম্পন্ন | On track, moderate progress
(
    'কুমারখালী উপজেলাধীন কুমারখালী সরকারি পাইলট উচ্চ বিদ্যালয়ের অতিরিক্ত শ্রেণিকক্ষ নির্মাণ',
    'R-25-26-002',
    2500000.00,
    500000.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (বিশেষ বরাদ্দ)',
    '২০২৫-২৬',
    'টেন্ডার',
    'কুমারখালী',
    'শিক্ষা',
    'কার্যাদেশ সম্পন্ন',
    20,
    0,
    0,
    72.00,
    '2025-07-15',
    '2026-01-31',
    NULL,
    'ঠিকাদার নির্বাচন সম্পন্ন; ফাউন্ডেশন কাজ শুরু হয়েছে',
    NULL
),

-- 003: Tender | ধর্মীয় ও সামাজিক | বাস্তবায়ন চলমান | DELAYED
(
    'ভেড়ামারা উপজেলাধীন ভেড়ামারা কেন্দ্রীয় জামে মসজিদ সংস্কার ও মিনার নির্মাণ কাজ',
    'R-25-26-003',
    800000.00,
    400000.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (সাধারণ বরাদ্দ)',
    '২০২৫-২৬',
    'টেন্ডার',
    'ভেড়ামারা',
    'ধর্মীয় ও সামাজিক',
    'বাস্তবায়ন চলমান',
    55,
    0,
    1,
    48.50,
    '2025-06-01',
    '2025-11-30',
    NULL,
    'নির্মাণ সামগ্রীর মূল্যবৃদ্ধি ও বর্ষা মৌসুমে কাজ ব্যাহত হওয়ায় প্রকল্প বিলম্বিত',
    NULL
),

-- 004: Tender | ক্রীড়া | বাস্তবায়ন সম্পন্ন | COMPLETED on time
(
    'দৌলতপুর উপজেলাধীন দৌলতপুর সরকারি স্টেডিয়াম মাঠ উন্নয়ন ও গ্যালারি সংস্কার কাজ',
    'R-25-26-004',
    3000000.00,
    3000000.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (বিশেষ বরাদ্দ)',
    '২০২৫-২৬',
    'টেন্ডার',
    'দৌলতপুর',
    'ক্রীড়া',
    'বাস্তবায়ন সম্পন্ন',
    100,
    1,
    0,
    91.00,
    '2025-05-15',
    '2025-10-31',
    '2025-10-28',
    'নির্ধারিত সময়ের পূর্বে কাজ সম্পন্ন; মান যাচাই ও গ্রহণ পরীক্ষা সম্পন্ন',
    NULL
),

-- ============================================================
-- সিপিপিসি projects (005–008)
-- ============================================================

-- 005: CPPC | শিক্ষা | প্রকল্পপত্র প্রেরণ সম্পন্ন | Very early stage
(
    'মিরপুর উপজেলাধীন মিরপুর সরকারি আদর্শ মাধ্যমিক বিদ্যালয়ের সীমানা প্রাচীর নির্মাণ কাজ',
    'R-25-26-005',
    350000.00,
    0.00,
    'এলজিএসপি-৩',
    '২০২৫-২৬',
    'সিপিপিসি',
    'মিরপুর',
    'শিক্ষা',
    'প্রকল্পপত্র প্রেরণ সম্পন্ন',
    5,
    0,
    0,
    NULL,
    '2025-08-01',
    '2025-12-31',
    NULL,
    'উপজেলা প্রকৌশল অফিস হতে প্রাক্কলন অনুমোদন প্রাপ্ত; কাজ শুরুর অপেক্ষায়',
    NULL
),

-- 006: CPPC | সেবামূলক | ১ম কিস্তি ছাড় সম্পন্ন | Mid-stage, on track
(
    'খোকসা উপজেলাধীন খোকসা উপজেলা স্বাস্থ্য কমপ্লেক্সের ওয়েটিং শেড ও বাউন্ডারি ওয়াল সংস্কার',
    'R-25-26-006',
    450000.00,
    225000.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (সাধারণ বরাদ্দ)',
    '২০২৫-২৬',
    'সিপিপিসি',
    'খোকসা',
    'সেবামূলক',
    '১ম কিস্তি ছাড় সম্পন্ন',
    50,
    0,
    0,
    78.00,
    '2025-07-20',
    '2025-12-20',
    NULL,
    '১ম কিস্তির কাজ যথাযথভাবে সম্পন্ন; সুপারভিশন রিপোর্ট দাখিল হয়েছে',
    NULL
),

-- 007: CPPC | ধর্মীয় ও সামাজিক | ২য় বিল দাখিলকৃত | DELAYED
(
    'কুষ্টিয়া সদর উপজেলাধীন কুষ্টিয়া শহীদ মিনার ও পার্শ্ববর্তী চত্বর সংস্কার ও সৌন্দর্যায়ন',
    'R-25-26-007',
    500000.00,
    250000.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (সাধারণ বরাদ্দ)',
    '২০২৫-২৬',
    'সিপিপিসি',
    'কুষ্টিয়া সদর',
    'ধর্মীয় ও সামাজিক',
    '২য় বিল দাখিলকৃত',
    65,
    0,
    1,
    52.00,
    '2025-06-15',
    '2025-11-15',
    NULL,
    '২য় বিল দাখিল হয়েছে; কিস্তি ছাড়ের অনুমোদন বিলম্বিত হওয়ায় কাজ আংশিক স্থগিত',
    NULL
),

-- 008: CPPC | ক্রীড়া | প্রকল্প বাস্তবায়িত | COMPLETED
(
    'কুমারখালী উপজেলাধীন কুমারখালী পৌর যুব ক্রীড়া সংসদ মাঠে সীমানা প্রাচীর ও ড্রেসিং রুম নির্মাণ',
    'R-25-26-008',
    480000.00,
    480000.00,
    'এলজিএসপি-৩',
    '২০২৫-২৬',
    'সিপিপিসি',
    'কুমারখালী',
    'ক্রীড়া',
    'প্রকল্প বাস্তবায়িত',
    100,
    1,
    0,
    88.50,
    '2025-06-10',
    '2025-10-31',
    '2025-10-25',
    'সকল কাজ নির্ধারিত মানে সম্পন্ন; সমাপ্তি প্রতিবেদন ও সম্পদ হস্তান্তর সম্পন্ন',
    NULL
),

-- ============================================================
-- আরএফকিউ projects (009–010)
-- ============================================================

-- 009: RFQ | সেবামূলক | কোটেশন আহ্বান সম্পন্ন | Early stage
(
    'দৌলতপুর উপজেলাধীন দৌলতপুর-মিরপুর আঞ্চলিক সড়কে বক্স কালভার্ট নির্মাণ কাজ',
    'R-25-26-009',
    700000.00,
    0.00,
    'জেলা পরিষদ উন্নয়ন সহায়তা (সাধারণ বরাদ্দ)',
    '২০২৫-২৬',
    'আরএফকিউ',
    'দৌলতপুর',
    'সেবামূলক',
    'কোটেশন আহ্বান সম্পন্ন',
    10,
    0,
    0,
    NULL,
    '2025-08-10',
    '2026-02-28',
    NULL,
    'তিনটি কোটেশন প্রাপ্ত; মূল্যায়ন কমিটির সুপারিশ প্রক্রিয়াধীন',
    NULL
),

-- 010: RFQ | শিক্ষা | প্রকল্প বাস্তবায়িত | COMPLETED, highest score
(
    'মিরপুর উপজেলাধীন মিরপুর মডেল সরকারি প্রাথমিক বিদ্যালয়ে ডিজিটাল ল্যাব স্থাপন ও আসবাবপত্র সরবরাহ',
    'R-25-26-010',
    250000.00,
    250000.00,
    'এলজিএসপি-৩',
    '২০২৫-২৬',
    'আরএফকিউ',
    'মিরপুর',
    'শিক্ষা',
    'প্রকল্প বাস্তবায়িত',
    100,
    1,
    0,
    94.00,
    '2025-07-01',
    '2025-09-30',
    '2025-09-22',
    'নির্ধারিত মেয়াদের আগেই ডিজিটাল ল্যাব স্থাপন ও উদ্বোধন সম্পন্ন',
    NULL
);


-- ============================================================
-- lat_lng UPDATE — seed realistic GPS coordinates per upazila
-- Run after 003_create_projects.sql ALTER TABLE (adds lat_lng column)
-- Coordinates are approximate upazila headquarters locations in Kushtia
-- ============================================================
-- NOTE: IDs in this table are auto-increment integers, not VARCHAR codes.
-- Adjust these WHERE clauses to match the actual inserted row IDs in your DB.
-- The order below matches the INSERT order above (001→1, 002→2, etc.)
UPDATE `projects` SET `lat_lng` = '23.9088,89.1218' WHERE id=1;  -- কুষ্টিয়া সদর
UPDATE `projects` SET `lat_lng` = '23.8721,89.2482' WHERE id=2;  -- কুমারখালী
UPDATE `projects` SET `lat_lng` = '24.0285,88.9812' WHERE id=3;  -- ভেড়ামারা
UPDATE `projects` SET `lat_lng` = '23.7645,88.9201' WHERE id=4;  -- দৌলতপুর
UPDATE `projects` SET `lat_lng` = '23.9523,89.0378' WHERE id=5;  -- মিরপুর
UPDATE `projects` SET `lat_lng` = '23.7874,89.1944' WHERE id=6;  -- খোকসা
UPDATE `projects` SET `lat_lng` = '23.9012,89.1195' WHERE id=7;  -- কুষ্টিয়া সদর
UPDATE `projects` SET `lat_lng` = '23.8698,89.2511' WHERE id=8;  -- কুমারখালী
UPDATE `projects` SET `lat_lng` = '23.7602,88.9335' WHERE id=9;  -- দৌলতপুর
UPDATE `projects` SET `lat_lng` = '23.9488,89.0412' WHERE id=10; -- মিরপুর


-- ============================================================
-- Populate project_approval_date for all seeded projects
-- ============================================================
UPDATE `projects` SET `project_approval_date` = '2025-05-15' WHERE `project_id` = 'R-25-26-001';
UPDATE `projects` SET `project_approval_date` = '2025-05-20' WHERE `project_id` = 'R-25-26-002';
UPDATE `projects` SET `project_approval_date` = '2025-05-10' WHERE `project_id` = 'R-25-26-003';
UPDATE `projects` SET `project_approval_date` = '2025-04-20' WHERE `project_id` = 'R-25-26-004';
UPDATE `projects` SET `project_approval_date` = '2025-06-01' WHERE `project_id` = 'R-25-26-005';
UPDATE `projects` SET `project_approval_date` = '2025-06-10' WHERE `project_id` = 'R-25-26-006';
UPDATE `projects` SET `project_approval_date` = '2025-05-25' WHERE `project_id` = 'R-25-26-007';
UPDATE `projects` SET `project_approval_date` = '2025-05-05' WHERE `project_id` = 'R-25-26-008';
UPDATE `projects` SET `project_approval_date` = '2025-06-20' WHERE `project_id` = 'R-25-26-009';
UPDATE `projects` SET `project_approval_date` = '2025-05-28' WHERE `project_id` = 'R-25-26-010';


-- ============================================================
-- Verification queries
-- ============================================================
-- SELECT id, project_id, LEFT(project_name,50) AS name, implementation_method,
--        project_type, current_status, is_completed, is_delayed
-- FROM projects ORDER BY id;
--
-- SELECT implementation_method, COUNT(*) AS total FROM projects GROUP BY implementation_method;
-- Expected: টেন্ডার=4, সিপিপিসি=4, আরএফকিউ=2
--
-- SELECT project_type, COUNT(*) AS total FROM projects GROUP BY project_type;
-- Expected: শিক্ষা=3, সেবামূলক=3, ধর্মীয় ও সামাজিক=2, ক্রীড়া=2
--
-- SELECT project_id, current_status, expected_end_date FROM projects WHERE is_delayed = 1;
-- Expected: R-25-26-003, R-25-26-007
--
-- SELECT project_id, actual_end_date, performance_score FROM projects WHERE is_completed = 1;
-- Expected: R-25-26-004, R-25-26-008, R-25-26-010
